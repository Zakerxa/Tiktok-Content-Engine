<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            // Pin collation explicitly so this table can never silently drift
            // from other tables — this mismatch is what caused the
            // "Illegal mix of collations" error when joining
            // users.role_name = roles.name.
            $table->charset   = 'utf8mb4';
            $table->collation = 'utf8mb4_unicode_ci';

            $table->id();
            $table->string('username', 100)->nullable()->unique();
            $table->string('email')->unique();
            $table->string('password')->nullable(); // nullable: google-only accounts have no password
            $table->string('api_key', 100)->nullable()->unique();
            $table->string('google_id', 100)->nullable()->unique();
            $table->string('avatar')->nullable();

            $table->string('role_name', 50)->default('tester');
            $table->foreign('role_name')->references('name')->on('roles');

            $table->boolean('is_active')->default(true);
            $table->integer('recap_limit')->default(0);
            $table->unsignedInteger('total_recap_used')->default(0);
            $table->dateTime('plan_expires_at')->nullable();
            $table->dateTime('session_expires_at')->nullable();

            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->charset   = 'utf8mb4';
            $table->collation = 'utf8mb4_unicode_ci';

            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
